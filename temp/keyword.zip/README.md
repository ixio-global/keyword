# 키워드 트렌드 모니터링 시스템

## 📌 프로젝트 개요
뉴스, 커뮤니티, 유튜브에서 키워드 트렌드를 2시간 주기로 자동 수집하고 분석하는 시스템입니다.

## 🏗️ 아키텍처

### 프론트엔드 (GitHub Pages)
- **기술 스택**: HTML5, Vanilla CSS, JavaScript
- **디자인**: Pretendard 폰트, 미니멀리즘 (화이트 배경)
- **페이지 구성**:
  - `index.html`: 대시보드 (추이 그래프, 데이터 테이블)
  - `admin.html`: 관리자 설정 (매체/키워드/알림 관리)

### 백엔드 (Firebase)
- **Firebase Functions**: 데이터 수집 및 분석
- **Firestore Database**: 키워드, 매체, 수집 데이터 저장
- **Firebase Auth**: 관리자 인증
- **Cloud Scheduler**: 2시간 주기 자동 실행

### AI 분석
- **통계 분석**: 언급량 추이 및 급증 패턴 감지

## 📂 프로젝트 구조

```
keyword/
├── public/                 # GitHub Pages 배포용
│   ├── index.html         # 대시보드
│   ├── admin.html         # 관리자 페이지
│   ├── css/
│   │   └── style.css      # 통합 스타일
│   └── js/
│       ├── dashboard.js   # 대시보드 로직
│       ├── admin.js       # 관리자 로직
│       └── firebase-config.js
├── functions/             # Firebase Functions
│   ├── index.js          # 메인 함수
│   ├── collectors/       # 데이터 수집기
│   │   ├── news.js
│   │   ├── community.js
│   │   └── youtube.js
│   └── package.json
├── firebase.json          # Firebase 설정
├── firestore.rules        # Firestore 보안 규칙
└── README.md
```

## 🧪 빠른 데모 테스트 (Firebase 설정 불필요)

Firebase 설정 전에 UI를 먼저 확인하고 싶으신가요? 데모 버전을 바로 실행하세요!

### 방법 1: 파일 직접 열기 (가장 빠름)
```
public/demo.html 파일을 브라우저에서 더블클릭하여 열기
```

### 방법 2: 배치 파일 사용 (Windows)
```bash
# 프로젝트 디렉토리에서
start-local-server.bat
```
자동으로 로컬 서버가 시작되고 브라우저가 열립니다.

### 방법 3: Python 사용
```bash
cd public
python -m http.server 8080
# 브라우저에서 http://localhost:8080/demo.html 접속
```

**데모 페이지**는 실제 Firebase 없이도 완전히 작동하는 샘플 데이터를 포함하고 있어, UI와 기능을 미리 확인할 수 있습니다!

---

## 🚀 배포 방법

상세한 배포 가이드는 [QUICKSTART.md](QUICKSTART.md)를 참고하세요.

### 1. Firebase 설정
```bash
npm install -g firebase-tools
firebase login
firebase init
```

### 2. Functions 배포
```bash
cd functions
npm install
firebase deploy --only functions
```

### 3. GitHub Pages 배포
```bash
git add .
git commit -m "Deploy to GitHub Pages"
git push origin main
```

## 🎨 디자인 가이드라인

- **폰트**: Pretendard
- **배경**: #FFFFFF (Pure White)
- **텍스트**: #212529 (Dark Gray)
- **포인트**: #007BFF (Blue)
- **레이아웃**: 미니멀리즘, 충분한 화이트 스페이스

## 📊 대상 매체

### 뉴스
- 구글 뉴스
- 네이버 뉴스

### 커뮤니티
- 디시인사이드
- 뽐뿌
- 루리웹
- 클리앙
- 블라인드
- 아사모 (네이버 카페)

### 유튜브 채널
- 잇섭
- 슈카월드
- UnderKG
- 가전주부
- 디에디트

## 🔔 알림 기능

트렌드 급증 시 알림 발송:
> [트렌드 급증] 키워드 '{키워드}'의 언급량이 전 주기 대비 {x}% 상승했습니다. (주요 매체: {매체명})

## 📝 라이선스
MIT License
